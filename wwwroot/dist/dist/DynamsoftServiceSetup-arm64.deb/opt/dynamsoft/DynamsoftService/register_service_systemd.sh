#!/bin/sh
cd /opt/dynamsoft/DynamsoftService

systemctl list-unit-files dynamsoft.service >/dev/null 2>&1 && systemctl disable dynamsoft.service >/dev/null 2>&1
systemctl daemon-reload
if [ -f "/usr/lib/systemd/system/dynamsoft.service" ]
then
	systemctl enable /usr/lib/systemd/system/dynamsoft.service >/dev/null 2>&1
elif [ -f "/lib/systemd/system/dynamsoft.service" ]
then
	systemctl enable /lib/systemd/system/dynamsoft.service >/dev/null 2>&1
else
	systemctl enable /opt/dynamsoft/DynamsoftService/dynamsoft.service >/dev/null 2>&1
fi
systemctl start dynamsoft.service

#/opt/dynamsoft/DynamsoftService/AutoStartMgr "/opt/dynamsoft/DynamsoftService/DynamsoftServiceMgr&"


