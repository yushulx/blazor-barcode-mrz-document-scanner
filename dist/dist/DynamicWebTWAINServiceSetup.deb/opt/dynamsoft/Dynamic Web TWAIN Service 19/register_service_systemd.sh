#!/bin/sh
DWT_INSTALL_PATH="/opt/dynamsoft/Dynamic Web TWAIN Service 19"
cd "${DWT_INSTALL_PATH}"

systemctl list-unit-files dynamsoft.dynamicwebtwain.service >/dev/null 2>&1 && systemctl disable dynamsoft.dynamicwebtwain.service >/dev/null 2>&1
systemctl daemon-reload
if [ -f "/usr/lib/systemd/system/dynamsoft.dynamicwebtwain.service" ]
then
	systemctl enable /usr/lib/systemd/system/dynamsoft.dynamicwebtwain.service >/dev/null 2>&1
elif [ -f "/lib/systemd/system/dynamsoft.dynamicwebtwain.service" ]
then
	systemctl enable /lib/systemd/system/dynamsoft.dynamicwebtwain.service >/dev/null 2>&1
else
	systemctl enable "${DWT_INSTALL_PATH}/dynamsoft.dynamicwebtwain.service" >/dev/null 2>&1
fi
systemctl start dynamsoft.dynamicwebtwain.service

#/opt/dynamsoft/DynamsoftService/AutoStartMgr "/opt/dynamsoft/DynamsoftService/DynamsoftServiceMgr&"


